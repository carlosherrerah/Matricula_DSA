#! /usr/bin/env python3

""" example module: extra.good.beta """

def FunB():
	return "Beta"

if __name__ == "__main__":
	print("I prefer to be a module")